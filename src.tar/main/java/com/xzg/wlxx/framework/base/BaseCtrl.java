package com.xzg.wlxx.framework.base;

import com.xzg.wlxx.framework.model.AjaxResult;
import io.swagger.annotations.Api;

@Api
public class BaseCtrl extends AjaxResult {

}
