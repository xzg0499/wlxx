package com.xzg.wlxx.framework.base;

import java.io.Serializable;

/**
 * @Author: 肖志刚
 * @Date: 2020/7/7 23:02
 */
public class BaseEntity implements Serializable {

}
