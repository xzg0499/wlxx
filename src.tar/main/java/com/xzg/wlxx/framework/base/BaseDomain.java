package com.xzg.wlxx.framework.base;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: xzgang
 * Date: 2020/11/16
 */
public class BaseDomain implements Serializable {
}
