package com.xzg.wlxx.framework.model;

/**
 * Created by IntelliJ IDEA.
 * User: xzgang
 * Date: 2020/11/15
 */
public enum AjaxMessge {
    QUERY_SUCCESS("成功！"),
    NULL("");

    private String msg;
    private AjaxMessge(String msg){

    }

}
