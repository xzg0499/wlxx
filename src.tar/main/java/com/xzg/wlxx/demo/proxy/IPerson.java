package com.xzg.wlxx.demo.proxy;

/**
 * Created by IntelliJ IDEA.
 * User: xzgang
 * Date: 2021/1/10
 */
public interface IPerson {
    public void saySomeThing();
}
